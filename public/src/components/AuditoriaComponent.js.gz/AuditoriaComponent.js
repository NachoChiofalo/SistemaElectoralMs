// AuditoriaComponent.js
// Componente para visualizar y filtrar registros de auditoria

(function(global) {

    /**
     * Cada operacion que efectivamente se audita en el backend (ver
     * `grep -rn "operacion:" src/modules`), no sólo las del padrón. Este mapa se había
     * quedado en las siete originales de cuando auditoría sólo cubría el padrón: faltaban
     * CREAR/EDITAR/ELIMINAR (listas, comicio, fiscales, fuerzas), LOGIN/LOGIN_FALLIDO/
     * LOGOUT (sesión) y ACTIVAR/DESACTIVAR/MODIFICAR (usuarios) — esas filas se veían con
     * el ícono genérico de fallback y no aparecían como opción en el filtro. 'EXPORTAR_CSV'
     * también estaba mal escrito como 'EXPORTAR_DATOS' y nunca hacía match.
     */
    const OPERACIONES = {
        'CREAR': { label: 'Crear', icon: 'fa-plus', clase: 'crear-votante' },
        'EDITAR': { label: 'Editar', icon: 'fa-edit', clase: 'actualizar-relevamiento' },
        'ELIMINAR': { label: 'Eliminar', icon: 'fa-trash', clase: 'eliminar-detalle' },
        'CREAR_VOTANTE': { label: 'Crear Votante', icon: 'fa-user-plus', clase: 'crear-votante' },
        'ACTUALIZAR_RELEVAMIENTO': { label: 'Actualizar Relev.', icon: 'fa-edit', clase: 'actualizar-relevamiento' },
        'CREAR_DETALLE': { label: 'Crear Detalle', icon: 'fa-plus-circle', clase: 'crear-detalle' },
        'ACTUALIZAR_DETALLE': { label: 'Actualizar Detalle', icon: 'fa-pen', clase: 'actualizar-detalle' },
        'ELIMINAR_DETALLE': { label: 'Eliminar Detalle', icon: 'fa-trash', clase: 'eliminar-detalle' },
        'IMPORTAR_CSV': { label: 'Importar CSV', icon: 'fa-file-csv', clase: 'importar-csv' },
        'EXPORTAR_CSV': { label: 'Exportar CSV', icon: 'fa-download', clase: 'exportar-datos' },
        'LOGIN': { label: 'Inicio de sesión', icon: 'fa-sign-in-alt', clase: 'crear-votante' },
        'LOGIN_FALLIDO': { label: 'Login fallido', icon: 'fa-exclamation-triangle', clase: 'eliminar-detalle' },
        'LOGOUT': { label: 'Cierre de sesión', icon: 'fa-sign-out-alt', clase: 'importar-csv' },
        'MODIFICAR': { label: 'Modificar', icon: 'fa-edit', clase: 'actualizar-relevamiento' },
        'ACTIVAR': { label: 'Activar', icon: 'fa-user-check', clase: 'crear-votante' },
        'DESACTIVAR': { label: 'Desactivar', icon: 'fa-user-slash', clase: 'eliminar-detalle' },
    };

    class AuditoriaComponent {
        constructor() {
            this.containerId = null;
            this.registros = [];
            this.estadisticas = null;
            this.paginacion = { paginaActual: 1, totalPaginas: 1, totalRegistros: 0 };
            this.filtros = {
                operacion: '',
                fecha_desde: '',
                fecha_hasta: '',
                page: 1,
                limit: 25
            };
        }

        async init(containerId) {
            this.containerId = containerId;
            this.render();
            await this.cargarDatos();
        }

        render() {
            const container = document.getElementById(this.containerId);
            if (!container) return;

            container.innerHTML = `
                <div class="auditoria-container">
                    <div class="auditoria-header">
                        <div class="auditoria-title">
                            <h1><i class="fas fa-clipboard-list" aria-hidden="true"></i> Auditoría</h1>
                            <p class="auditoria-subtitle">Quién tocó qué y cuándo: registro de operaciones del sistema</p>
                        </div>
                    </div>

                    <div id="auditoria-stats" class="auditoria-stats">
                        ${this.renderStatsLoading()}
                    </div>

                    <div class="auditoria-filtros">
                        <div class="filtros-grid">
                            <div class="filtro-group">
                                <label for="filtro-operacion">Operación</label>
                                <select id="filtro-operacion">
                                    <option value="">Todas</option>
                                    ${Object.entries(OPERACIONES).map(([key, val]) =>
                                        `<option value="${key}">${val.label}</option>`
                                    ).join('')}
                                </select>
                            </div>
                            <div class="filtro-group">
                                <label for="filtro-fecha-desde">Desde</label>
                                <input type="date" id="filtro-fecha-desde">
                            </div>
                            <div class="filtro-group">
                                <label for="filtro-fecha-hasta">Hasta</label>
                                <input type="date" id="filtro-fecha-hasta">
                            </div>
                            <div class="filtros-acciones">
                                <button class="btn btn-primary" id="btn-filtrar">
                                    <i class="fas fa-search"></i> Filtrar
                                </button>
                                <button class="btn btn-secondary" id="btn-limpiar">
                                    <i class="fas fa-times"></i> Limpiar
                                </button>
                            </div>
                        </div>
                    </div>

                    <div id="auditoria-tabla-wrapper">
                        <div class="auditoria-loading">
                            <i class="fas fa-spinner"></i>
                            <p>Cargando registros de auditoría…</p>
                        </div>
                    </div>
                </div>
            `;

            this.setupEventListeners();
        }

        setupEventListeners() {
            const btnFiltrar = document.getElementById('btn-filtrar');
            const btnLimpiar = document.getElementById('btn-limpiar');

            if (btnFiltrar) {
                btnFiltrar.addEventListener('click', () => this.aplicarFiltros());
            }
            if (btnLimpiar) {
                btnLimpiar.addEventListener('click', () => this.limpiarFiltros());
            }
        }

        /**
         * Registros y estadisticas se piden por separado: las estadisticas no dependen
         * de la pagina (`cambiarPagina` sólo re-pide el listado). Antes las dos siempre
         * viajaban juntas, así que hojear páginas relanzaba las cinco agregaciones de
         * `estadisticas()` sin que ninguno de sus números hubiera cambiado.
         */
        async cargarDatos() {
            await Promise.all([this.cargarRegistros(), this.cargarEstadisticas()]);
        }

        async cargarRegistros() {
            try {
                const auditoriaRes = await window.apiService.obtenerAuditoria(this.filtros);
                if (auditoriaRes && auditoriaRes.success) {
                    this.registros = auditoriaRes.data || [];
                    this.paginacion = auditoriaRes.paginacion || { paginaActual: 1, totalPaginas: 1, totalRegistros: 0 };
                }
                this.renderTabla();
            } catch (error) {
                console.error('Error cargando auditoria:', error);
                this.renderError();
            }
        }

        async cargarEstadisticas() {
            try {
                const statsRes = await window.apiService.obtenerEstadisticasAuditoria({
                    fecha_desde: this.filtros.fecha_desde,
                    fecha_hasta: this.filtros.fecha_hasta
                });
                if (statsRes && statsRes.success) {
                    this.estadisticas = statsRes.data;
                }
                this.renderStats();
            } catch (error) {
                console.error('Error cargando estadisticas de auditoria:', error);
            }
        }

        renderStatsLoading() {
            return `
                <div class="stat-card"><div class="auditoria-loading"><i class="fas fa-spinner"></i></div></div>
                <div class="stat-card"><div class="auditoria-loading"><i class="fas fa-spinner"></i></div></div>
                <div class="stat-card"><div class="auditoria-loading"><i class="fas fa-spinner"></i></div></div>
            `;
        }

        renderStats() {
            const statsContainer = document.getElementById('auditoria-stats');
            if (!statsContainer || !this.estadisticas) return;

            const stats = this.estadisticas;
            const opMasFrecuente = stats.porTipo && stats.porTipo.length > 0
                ? OPERACIONES[stats.porTipo[0].operacion]?.label || stats.porTipo[0].operacion
                : 'N/A';

            statsContainer.innerHTML = `
                <div class="stat-card">
                    <div class="stat-icon total"><i class="fas fa-list"></i></div>
                    <div class="stat-info">
                        <div class="stat-value">${stats.totalOperaciones || 0}</div>
                        <div class="stat-label">Total operaciones</div>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon usuarios"><i class="fas fa-users"></i></div>
                    <div class="stat-info">
                        <div class="stat-value">${stats.usuariosActivos ?? 0}</div>
                        <div class="stat-label">Usuarios activos ahora</div>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon operacion"><i class="fas fa-star"></i></div>
                    <div class="stat-info">
                        <div class="stat-value">${opMasFrecuente}</div>
                        <div class="stat-label">Operación más frecuente</div>
                    </div>
                </div>
            `;
        }

        renderTabla() {
            const wrapper = document.getElementById('auditoria-tabla-wrapper');
            if (!wrapper) return;

            if (this.registros.length === 0) {
                wrapper.innerHTML = `
                    <div class="auditoria-tabla-container">
                        <div class="auditoria-vacia">
                            <i class="fas fa-clipboard-check"></i>
                            <p>No se encontraron registros de auditoria</p>
                        </div>
                    </div>
                `;
                return;
            }

            wrapper.innerHTML = `
                <div class="auditoria-tabla-container">
                    <div class="auditoria-tabla-header">
                        <h2>Registros de auditoría</h2>
                        <span class="registro-count">${this.paginacion.totalRegistros} registros encontrados</span>
                    </div>
                    <table class="auditoria-tabla">
                        <thead>
                            <tr>
                                <th>Fecha</th>
                                <th>Usuario</th>
                                <th>Operacion</th>
                                <th>Entidad</th>
                                <th>DNI/ID</th>
                                <th>Detalles</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${this.registros.map(r => this.renderFila(r)).join('')}
                        </tbody>
                    </table>
                    ${this.renderPaginacion()}
                </div>
            `;

            // Event listeners for row clicks
            // La fila entera abre el detalle: con mouse (clic) y con teclado (Enter o Espacio, con foco).
            wrapper.querySelectorAll('.fila-auditoria').forEach(fila => {
                const abrir = () => {
                    const registro = this.registros.find(r => String(r.id) === fila.dataset.id);
                    if (registro) this.mostrarDetalle(registro);
                };
                fila.addEventListener('click', abrir);
                fila.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); abrir(); }
                });
            });

            // Paginación (lib/paginacion.js): botones por data-pagina, campo "Ir a" por enlazar.
            const nav = document.querySelector('.auditoria-paginacion');
            if (nav) {
                nav.addEventListener('click', (e) => {
                    const btn = e.target.closest('[data-pagina]');
                    if (btn && !btn.disabled) this.irAPagina(Number(btn.dataset.pagina));
                });
                window.paginacion.enlazar(nav, (pagina) => this.irAPagina(pagina));
            }
        }

        renderFila(registro) {
            const op = OPERACIONES[registro.operacion] || { label: registro.operacion, icon: 'fa-circle', clase: '' };
            const fecha = new Date(registro.created_at);
            const fechaStr = fecha.toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit', year: 'numeric' });
            const horaStr = fecha.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' });

            return `
                <tr class="fila-auditoria" data-id="${registro.id}" tabindex="0" aria-label="Ver el detalle: ${op.label}, ${this.escapeHtml(registro.usuario_nombre || registro.usuario_username)}, ${fechaStr} ${horaStr}">
                    <td>
                        <div class="fecha-texto">${fechaStr}</div>
                        <div class="fecha-texto">${horaStr}</div>
                    </td>
                    <td>
                        <div class="usuario-info">
                            <span class="usuario-nombre">${this.escapeHtml(registro.usuario_nombre)}</span>
                            <span class="usuario-username">@${this.escapeHtml(registro.usuario_username)}</span>
                        </div>
                    </td>
                    <td>
                        <span class="badge-operacion ${op.clase}">
                            <i class="fas ${op.icon}" aria-hidden="true"></i> ${op.label}
                        </span>
                    </td>
                    <td>${this.escapeHtml(registro.entidad)}</td>
                    <td>${registro.entidad_id ? this.escapeHtml(registro.entidad_id) : '-'}</td>
                    <td>${registro.detalles ? this.escapeHtml(this.truncar(registro.detalles, 50)) : '-'}</td>
                </tr>
            `;
        }

        renderPaginacion() {
            const { paginaActual, totalPaginas } = this.paginacion;
            return `
                <div class="auditoria-paginacion">${window.paginacion.render({
                    pagina: paginaActual,
                    totalPaginas,
                    etiqueta: 'Paginación de auditoría'
                })}</div>
            `;
        }

        mostrarDetalle(registro) {
            const op = OPERACIONES[registro.operacion] || { label: registro.operacion, icon: 'fa-circle', clase: '' };
            const fecha = new Date(registro.created_at);
            const fechaCompleta = fecha.toLocaleString('es-AR', {
                day: '2-digit', month: '2-digit', year: 'numeric',
                hour: '2-digit', minute: '2-digit', second: '2-digit'
            });

            const datosAnteriores = registro.datos_anteriores
                ? JSON.stringify(registro.datos_anteriores, null, 2)
                : null;
            const datosNuevos = registro.datos_nuevos
                ? JSON.stringify(registro.datos_nuevos, null, 2)
                : null;

            // El detalle es un diálogo del sistema (foco atrapado, Escape, fondo inerte, foco de vuelta
            // a la fila que lo abrió), no un overlay armado a mano.
            const cuerpo = document.createElement('div');
            cuerpo.innerHTML = `
                    <div class="detalle-campo">
                        <div class="campo-label">Operación</div>
                        <div class="campo-valor">
                            <span class="badge-operacion ${op.clase}">
                                <i class="fas ${op.icon}" aria-hidden="true"></i> ${op.label}
                            </span>
                        </div>
                    </div>
                    <div class="detalle-campo">
                        <div class="campo-label">Fecha y Hora</div>
                        <div class="campo-valor">${fechaCompleta}</div>
                    </div>
                    <div class="detalle-campo">
                        <div class="campo-label">Usuario</div>
                        <div class="campo-valor">${this.escapeHtml(registro.usuario_nombre)} (@${this.escapeHtml(registro.usuario_username)})</div>
                    </div>
                    <div class="detalle-campo">
                        <div class="campo-label">Entidad</div>
                        <div class="campo-valor">${this.escapeHtml(registro.entidad)} ${registro.entidad_id ? '(ID: ' + this.escapeHtml(registro.entidad_id) + ')' : ''}</div>
                    </div>
                    ${registro.detalles ? `
                    <div class="detalle-campo">
                        <div class="campo-label">Descripción</div>
                        <div class="campo-valor">${this.escapeHtml(registro.detalles)}</div>
                    </div>
                    ` : ''}
                    ${registro.ip_address ? `
                    <div class="detalle-campo">
                        <div class="campo-label">Dirección IP</div>
                        <div class="campo-valor">${this.escapeHtml(registro.ip_address)}</div>
                    </div>
                    ` : ''}
                    ${(datosAnteriores || datosNuevos) ? `
                    <div class="detalle-campo">
                        <div class="campo-label">Datos</div>
                        <div class="datos-comparacion">
                            ${datosAnteriores ? `
                            <div class="datos-col">
                                <h3>Antes</h3>
                                <div class="datos-json">${this.escapeHtml(datosAnteriores)}</div>
                            </div>
                            ` : ''}
                            ${datosNuevos ? `
                            <div class="datos-col">
                                <h3>Después</h3>
                                <div class="datos-json">${this.escapeHtml(datosNuevos)}</div>
                            </div>
                            ` : ''}
                        </div>
                    </div>
                    ` : ''}
                
            `;

            window.dialogo.abrir({
                titulo: 'Detalle de la operación',
                icono: op.icon,
                cuerpo,
                ancho: true,
                acciones: [{ id: 'cerrar', texto: 'Cerrar', tipo: 'secundario', foco: true }],
            });
        }

        aplicarFiltros() {
            this.filtros.operacion = document.getElementById('filtro-operacion')?.value || '';
            this.filtros.fecha_desde = document.getElementById('filtro-fecha-desde')?.value || '';
            this.filtros.fecha_hasta = document.getElementById('filtro-fecha-hasta')?.value || '';
            this.filtros.page = 1;
            this.cargarDatos();
        }

        limpiarFiltros() {
            const opSelect = document.getElementById('filtro-operacion');
            const desdeInput = document.getElementById('filtro-fecha-desde');
            const hastaInput = document.getElementById('filtro-fecha-hasta');

            if (opSelect) opSelect.value = '';
            if (desdeInput) desdeInput.value = '';
            if (hastaInput) hastaInput.value = '';

            this.filtros = { operacion: '', fecha_desde: '', fecha_hasta: '', page: 1, limit: 25 };
            this.cargarDatos();
        }

        irAPagina(nuevaPagina) {
            if (nuevaPagina < 1 || nuevaPagina > this.paginacion.totalPaginas) return;
            this.filtros.page = nuevaPagina;
            this.cargarRegistros();
        }

        renderError() {
            const wrapper = document.getElementById('auditoria-tabla-wrapper');
            if (!wrapper) return;
            wrapper.innerHTML = `
                <div class="auditoria-tabla-container">
                    <div class="auditoria-vacia">
                        <i class="fas fa-exclamation-triangle"></i>
                        <p>Error al cargar los registros de auditoria</p>
                    </div>
                </div>
            `;
        }

        truncar(texto, max) {
            if (!texto) return '';
            return texto.length > max ? texto.substring(0, max) + '…' : texto;
        }

        /**
         * Escapa un dato antes de interpolarlo en HTML.
         *
         * Delega en el helper compartido (`src/lib/escapar.js`). Antes era
         * `div.textContent = x; return div.innerHTML`, que escapa `&`, `<` y `>` pero **no
         * las comillas** — y acá se usa dentro de atributos (`data-username="${...}"`), donde
         * eso no alcanza: un valor que empiece con comilla se sale del atributo.
         */
        escapeHtml(texto) {
            return escaparHtml(texto);
        }
    }

    // Global instance
    global.auditoriaComponent = new AuditoriaComponent();

})(window);
