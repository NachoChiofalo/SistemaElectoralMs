/**
 * Componente de Login para autenticación
 */
class LoginComponent {
    constructor() {
        this.element = null;
        this.isLoading = false;
        this.cooldownTimerId = null;
        this.cooldownRemaining = 0;
    }

    /**
     * Renderizar componente de login
     */
    render() {
        const html = `
            <div class="login-container">
                <div class="login-card">
                    <div class="login-header">
                        <h1 class="login-logo">
                            <img src="/assets/images/agora-logo.png" alt="ÁGORA">
                        </h1>
                    </div>

                    <form id="loginForm" class="login-form">
                        <div class="form-group">
                            <label for="username">  
                                <i class="fas fa-user"></i>
                                Usuario
                            </label>
                            <input 
                                type="text" 
                                id="username" 
                                name="username" 
                                required
                                autocomplete="username"
                                placeholder="Ingrese su usuario"
                            >
                        </div>

                        <div class="form-group">
                            <label for="password">
                                <i class="fas fa-lock"></i>
                                Contraseña
                            </label>
                            <input 
                                type="password" 
                                id="password" 
                                name="password" 
                                required
                                autocomplete="current-password"
                                placeholder="Ingrese su contraseña"
                            >
                        </div>

                        <button type="submit" class="login-btn" id="loginBtn">
                            <i class="fas fa-sign-in-alt"></i>
                            Iniciar Sesión
                        </button>

                        <div id="loginError" class="error-message" role="alert" aria-live="assertive" style="display: none;"></div>
                    </form>

                    
                </div>
            </div>
        `;

        this.element = document.createElement('div');
        this.element.innerHTML = html;
        
        this.initEventListeners();
        
        return this.element;
    }

    /**
     * Inicializar event listeners
     */
    initEventListeners() {
        const form = this.element.querySelector('#loginForm');
        form.addEventListener('submit', (e) => this.handleLogin(e));

        // Auto-focus en el campo de usuario
        setTimeout(() => {
            const usernameInput = this.element.querySelector('#username');
            usernameInput?.focus();
        }, 100);

        // Enter en password field
        const passwordInput = this.element.querySelector('#password');
        passwordInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.handleLogin(e);
            }
        });
    }

    /**
     * Manejar intento de login
     */
    async handleLogin(e) {
        e.preventDefault();

        if (this.isLoading || this.cooldownTimerId) return;

        const form = e.target.closest('form');
        const formData = new FormData(form);
        const username = formData.get('username').trim();
        const password = formData.get('password');

        if (!username || !password) {
            this.showError('Por favor complete todos los campos');
            return;
        }

        this.setLoading(true);
        this.hideError();

        let cooldownSeconds = null;

        try {
            const result = await window.authService.login(username, password);
            
            // Login exitoso
            console.log('✅ Login exitoso:', result.user);
            
            // Mostrar mensaje de éxito
            this.showSuccess(`¡Bienvenido/a, ${result.user.nombre_completo}!`);
            
            // Esperar un momento y luego redirigir al dashboard
            setTimeout(() => {
                window.location.href = 'dashboard.html';
            }, 1500);

        } catch (error) {
            console.error('❌ Error en login:', error);
            this.showError(error.message || 'Error al iniciar sesión');
            // No dejar una clave ya rechazada lista para reenviarse (FE-051).
            const campoPassword = document.getElementById('password');
            if (campoPassword) { campoPassword.value = ''; campoPassword.focus(); }
            if (error.rateLimited) {
                cooldownSeconds = Number.isFinite(error.retryAfter) ? error.retryAfter : 10;
            }
        } finally {
            this.setLoading(false);
            if (cooldownSeconds) {
                this.startRateLimitCooldown(cooldownSeconds);
            }
        }
    }

    /**
     * Configurar estado de carga
     */
    setLoading(loading) {
        this.isLoading = loading;
        const btn = this.element.querySelector('#loginBtn');
        const inputs = this.element.querySelectorAll('input');

        if (loading) {
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Iniciando sesión...';
            btn.disabled = true;
            inputs.forEach(input => input.disabled = true);
        } else {
            btn.innerHTML = '<i class="fas fa-sign-in-alt"></i> Iniciar Sesión';
            btn.disabled = false;
            inputs.forEach(input => input.disabled = false);
        }
    }

    startRateLimitCooldown(seconds) {
        const btn = this.element.querySelector('#loginBtn');
        if (!btn) return;

        if (this.cooldownTimerId) {
            clearInterval(this.cooldownTimerId);
            this.cooldownTimerId = null;
        }

        this.cooldownRemaining = Math.max(1, Math.ceil(seconds));
        btn.disabled = true;

        const updateButton = () => {
            if (this.cooldownRemaining <= 0) {
                clearInterval(this.cooldownTimerId);
                this.cooldownTimerId = null;
                btn.innerHTML = '<i class="fas fa-sign-in-alt"></i> Iniciar Sesión';
                btn.disabled = false;
                return;
            }

            btn.innerHTML = `<i class="fas fa-hourglass-half"></i> Reintentar en ${this.cooldownRemaining}s`;
            this.cooldownRemaining -= 1;
        };

        updateButton();
        this.cooldownTimerId = setInterval(updateButton, 1000);
    }

    /**
     * Mostrar error
     */
    showError(message) {
        const errorDiv = this.element.querySelector('#loginError');
        errorDiv.textContent = message;
        errorDiv.style.display = 'block';
        
        // Auto-hide después de 5 segundos
        setTimeout(() => this.hideError(), 5000);
    }

    /**
     * Ocultar error
     */
    hideError() {
        const errorDiv = this.element.querySelector('#loginError');
        errorDiv.style.display = 'none';
    }

    /**
     * Mostrar mensaje de éxito
     */
    showSuccess(message) {
        const errorDiv = this.element.querySelector('#loginError');
        errorDiv.textContent = message;
        errorDiv.style.display = 'block';
        errorDiv.style.background = '#d4edda';
        errorDiv.style.color = '#155724';
        errorDiv.style.borderColor = '#c3e6cb';
    }
}

// Inicializar componente de login
window.loginComponent = new LoginComponent();